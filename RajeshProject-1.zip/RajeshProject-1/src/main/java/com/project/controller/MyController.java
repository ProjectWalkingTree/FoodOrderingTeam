package com.project.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.entity.Userdetails;
import com.project.repository.UserRepository;

@Controller
public class MyController {

@Autowired
private UserRepository rapo;
 @GetMapping("/")
 public String home() 
 {
	 return "index";
 }
 
 @PostMapping("/register")
 public String register(@ModelAttribute Userdetails u,HttpSession session)
 {
	 System.out.println(u);
	 rapo.save(u);
	 session.setAttribute("messege","User Registered Successfully");
	 return "redirect:/";
 }
}
